function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5XXimH34HtG":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

